# ReelForge AI

ReelForge AI turns a topic into an editable short-video storyboard, then renders an MP4 from user-supplied media or simple local backgrounds.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — API service at the configured `/api` path
- `pnpm --filter @workspace/reelforge-ai run dev` — web app
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API client and Zod types after OpenAPI changes
- `pnpm run typecheck` — check shared libraries and workspace packages

The current ReelForge draft and render endpoints require no AI API key or other paid-provider credential. The app does not persist user data in a database.

## Stack

- pnpm workspace, Node.js 24, TypeScript
- Web: React, Vite, Wouter, generated React Query hooks
- API: Express 5, OpenAPI contract, generated Zod validation
- Rendering: FFmpeg and ffprobe, with temporary files under the system temp directory

## Where things live

- `artifacts/reelforge-ai/` — dashboard, editor, local project storage, upload controls, and preview
- `artifacts/api-server/src/routes/drafts.ts` — template draft and temporary FFmpeg render routes
- `lib/api-spec/openapi.yaml` — source of truth for the API and generated client types

## Product

- Creates deterministic English, Hindi, and Spanish script starters from reusable templates; these are not model-generated.
- Lets users edit narration and captions, upload stills, narration, and licensed music, adjust mix levels, preview a rendered MP4, and download it.
- Generates MP4 locally on the API service, including timed caption tracks and scene transitions.

## Architecture decisions

- Do not claim an AI task succeeded without an actual result. No hosted AI or media-generation service is connected.
- Do not silently add or switch to a paid service. Ask for explicit approval before introducing any paid provider.
- Project metadata is saved in this browser's local storage. Uploaded media is kept in the editing session and only sent to the API when the user requests a render.
- Render jobs and media are temporary, held in process memory and system temp storage, and expire after about one hour. A service restart can discard a job before then.
- Render limits are intentional: 15–60 seconds, up to six still images, 8 MB per image, 12 MB per audio file, 36 MB total, and three active/queued jobs.
- Do not describe the app or Replit hosting as free without verifying current hosting and runtime limits. The code has no paid AI API dependency, but rendering needs FFmpeg support and temporary disk space.

## Gotchas

- When changing an API shape, update `lib/api-spec/openapi.yaml` and rerun codegen before using its generated types.
- Browser-local project data does not include image/audio file bytes. Those files must be selected again after reloading the editor.
- Server-side render jobs are not durable and are not shared across API processes.