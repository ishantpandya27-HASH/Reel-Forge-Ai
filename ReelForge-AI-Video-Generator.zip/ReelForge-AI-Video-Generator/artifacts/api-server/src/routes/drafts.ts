import { randomUUID } from "node:crypto";
import { mkdirSync, mkdtempSync } from "node:fs";
import {
  mkdir,
  open,
  readFile,
  rm,
  stat,
  writeFile,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { execFile, spawn } from "node:child_process";
import multer from "multer";
import { Router, type IRouter, type Request, type RequestHandler } from "express";
import {
  CreateDraftBody,
  CreateDraftResponse,
  CreateRenderJobResponse,
  GetCapabilitiesResponse,
  GetRenderJobParams,
  GetRenderJobResponse,
} from "@workspace/api-zod";
import type { RenderJob, RenderMetadata } from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const renderRoot = join(tmpdir(), "reelforge-render");
mkdirSync(renderRoot, { recursive: true });
const renderJobs = new Map<string, { result: RenderJob; directory: string; createdAt: number }>();
const renderQueue: string[] = [];
let isRendering = false;
const MAX_QUEUED_JOBS = 3;
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const MAX_AUDIO_BYTES = 12 * 1024 * 1024;
const TRANSITION_SECONDS = 0.35;

type RequestWithRenderDirectory = Request & { renderDirectory?: string };

const imageExtensions: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
};
const audioExtensions: Record<string, string> = {
  "audio/mpeg": ".mp3",
  "audio/mp4": ".m4a",
  "audio/x-m4a": ".m4a",
  "audio/aac": ".aac",
  "audio/wav": ".wav",
  "audio/x-wav": ".wav",
  "audio/ogg": ".ogg",
};

const renderUpload = multer({
  storage: multer.diskStorage({
    destination(req, _file, callback) {
      const directory = (req as RequestWithRenderDirectory).renderDirectory;
      if (!directory) {
        callback(new Error("Temporary render directory was not prepared."), "");
        return;
      }
      callback(null, directory);
    },
    filename(_req, file, callback) {
      callback(null, `${randomUUID()}${imageExtensions[file.mimetype] ?? audioExtensions[file.mimetype] ?? ".bin"}`);
    },
  }),
  limits: {
    files: 8,
    fields: 1,
    fieldSize: 64 * 1024,
    fileSize: MAX_AUDIO_BYTES,
  },
  fileFilter(_req, file, callback) {
    if (!imageExtensions[file.mimetype] && !audioExtensions[file.mimetype]) {
      callback(new Error("Unsupported file type. Use PNG, JPEG, WebP, MP3, WAV, AAC, M4A, or OGG."));
      return;
    }
    callback(null, true);
  },
});

const parseRenderUpload: RequestHandler = (req, res, next) => {
  const directory = mkdtempSync(join(renderRoot, "job-"));
  (req as RequestWithRenderDirectory).renderDirectory = directory;
  renderUpload.fields([
    { name: "metadata", maxCount: 1 },
    { name: "images", maxCount: 6 },
    { name: "narration", maxCount: 1 },
    { name: "music", maxCount: 1 },
  ])(req, res, (error) => {
    if (error) {
      void rm(directory, { recursive: true, force: true });
      res.status(400).json({ error: error.message });
      return;
    }
    next();
  });
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function parseRenderMetadata(
  source: unknown,
  imageCount: number,
): RenderMetadata | null {
  if (typeof source !== "string") return null;
  let value: unknown;
  try {
    value = JSON.parse(source);
  } catch {
    return null;
  }
  if (!isRecord(value)) return null;
  const allowedDurations = [15, 30, 45, 60];
  const allowedRatios = ["9:16", "16:9", "1:1"];
  if (
    typeof value.title !== "string" ||
    value.title.trim().length === 0 ||
    value.title.length > 100 ||
    typeof value.durationSeconds !== "number" ||
    !allowedDurations.includes(value.durationSeconds) ||
    typeof value.aspectRatio !== "string" ||
    !allowedRatios.includes(value.aspectRatio) ||
    !Array.isArray(value.scenes) ||
    value.scenes.length < 1 ||
    value.scenes.length > 12 ||
    (value.narrationVolume !== undefined &&
      (typeof value.narrationVolume !== "number" ||
        value.narrationVolume < 0 ||
        value.narrationVolume > 2)) ||
    (value.musicVolume !== undefined &&
      (typeof value.musicVolume !== "number" ||
        value.musicVolume < 0 ||
        value.musicVolume > 0.5))
  ) {
    return null;
  }

  const scenes: RenderMetadata["scenes"] = [];
  for (let index = 0; index < value.scenes.length; index += 1) {
    const scene = value.scenes[index];
    if (
      !isRecord(scene) ||
      scene.order !== index + 1 ||
      typeof scene.durationSeconds !== "number" ||
      scene.durationSeconds < 0.25 ||
      scene.durationSeconds > 60 ||
      typeof scene.caption !== "string" ||
      scene.caption.length > 160 ||
      !(scene.imageIndex === null ||
        (Number.isInteger(scene.imageIndex) &&
          typeof scene.imageIndex === "number" &&
          scene.imageIndex >= 0 &&
          scene.imageIndex < imageCount))
    ) {
      return null;
    }
    scenes.push({
      order: scene.order,
      durationSeconds: scene.durationSeconds,
      caption: scene.caption,
      imageIndex: scene.imageIndex,
    });
  }

  const sceneDuration = scenes.reduce(
    (sum, scene) => sum + scene.durationSeconds,
    0,
  );
  if (Math.abs(sceneDuration - value.durationSeconds) > 0.5) return null;

  return {
    title: value.title.trim(),
    durationSeconds: value.durationSeconds as RenderMetadata["durationSeconds"],
    aspectRatio: value.aspectRatio as RenderMetadata["aspectRatio"],
    scenes,
    narrationVolume: typeof value.narrationVolume === "number" ? value.narrationVolume : 1,
    musicVolume: typeof value.musicVolume === "number" ? value.musicVolume : 0.16,
  };
}

async function hasValidMediaSignature(
  file: Express.Multer.File,
  kind: "image" | "audio",
): Promise<boolean> {
  const handle = await open(file.path, "r");
  const signature = Buffer.alloc(16);
  try {
    await handle.read(signature, 0, signature.length, 0);
  } finally {
    await handle.close();
  }

  if (kind === "image") {
    return (
      signature.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) ||
      (signature[0] === 0xff && signature[1] === 0xd8 && signature[2] === 0xff) ||
      (signature.toString("ascii", 0, 4) === "RIFF" &&
        signature.toString("ascii", 8, 12) === "WEBP")
    );
  }
  return (
    signature.toString("ascii", 0, 4) === "RIFF" ||
    signature.toString("ascii", 0, 4) === "OggS" ||
    signature.toString("ascii", 0, 3) === "ID3" ||
    signature.toString("ascii", 4, 8) === "ftyp" ||
    (signature[0] === 0xff && (signature[1] & 0xe0) === 0xe0) ||
    (signature[0] === 0xff && (signature[1] & 0xf6) === 0xf0)
  );
}

function safeJobUpdate(
  jobId: string,
  updates: Partial<RenderJob>,
): void {
  const job = renderJobs.get(jobId);
  if (!job) return;
  job.result = CreateRenderJobResponse.parse({ ...job.result, ...updates });
}

function escapeFilterPath(path: string): string {
  return path.replaceAll("\\", "\\\\").replaceAll(":", "\\:");
}

function formatSrtTime(seconds: number): string {
  const milliseconds = Math.max(0, Math.round(seconds * 1000));
  const hours = Math.floor(milliseconds / 3_600_000);
  const minutes = Math.floor((milliseconds % 3_600_000) / 60_000);
  const wholeSeconds = Math.floor((milliseconds % 60_000) / 1000);
  const remainder = milliseconds % 1000;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(wholeSeconds).padStart(2, "0")},${String(remainder).padStart(3, "0")}`;
}

async function runFfmpeg(
  jobId: string,
  args: string[],
  expectedDuration: number,
): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const child = spawn("ffmpeg", args, { stdio: ["ignore", "pipe", "pipe"] });
    let progressText = "";
    let errorText = "";
    child.stdout.on("data", (chunk: Buffer) => {
      progressText += chunk.toString();
      const lines = progressText.split("\n");
      progressText = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("out_time_ms=")) continue;
        const seconds = Number(line.slice("out_time_ms=".length)) / 1_000_000;
        if (!Number.isFinite(seconds)) continue;
        safeJobUpdate(jobId, {
          status: "running",
          stage: "rendering",
          message: "Rendering MP4 with FFmpeg",
          progress: Math.min(97, Math.max(2, Math.round((seconds / expectedDuration) * 96))),
        });
      }
    });
    child.stderr.on("data", (chunk: Buffer) => {
      errorText = `${errorText}${chunk.toString()}`.slice(-5000);
    });
    child.once("error", reject);
    child.once("close", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`FFmpeg exited with status ${String(code)}: ${errorText}`));
      }
    });
  });
}

async function probeDuration(videoPath: string): Promise<number> {
  const output = await new Promise<string>((resolve, reject) => {
    execFile(
      "ffprobe",
      [
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        videoPath,
      ],
      { encoding: "utf8", timeout: 10000 },
      (error, stdout) => {
        if (error) {
          reject(error);
          return;
        }
        resolve(stdout);
      },
    );
  });
  const duration = Number(output.trim());
  if (!Number.isFinite(duration) || duration <= 0) {
    throw new Error("The rendered video could not be verified.");
  }
  return duration;
}

async function renderOneJob(jobId: string): Promise<void> {
  const record = renderJobs.get(jobId);
  if (!record) return;
  const metadataPath = join(record.directory, "metadata.json");
  const metadata = JSON.parse(await readFile(metadataPath, "utf8")) as RenderMetadata;
  const files = JSON.parse(
    await readFile(join(record.directory, "uploads.json"), "utf8"),
  ) as { images: string[]; narration: string | null; music: string | null };
  const outputPath = join(record.directory, "render.mp4");
  const width = metadata.aspectRatio === "9:16" ? 720 : 960;
  const height = metadata.aspectRatio === "9:16" ? 1280 : metadata.aspectRatio === "1:1" ? 960 : 540;
  const inputArgs: string[] = ["-hide_banner", "-loglevel", "error", "-y"];
  const filterParts: string[] = [];
  const sceneLabels: string[] = [];
  const transitionDurations: number[] = [];
  const palette = ["0x142238", "0x25344c", "0x293044", "0x1d3540", "0x3a2d3f", "0x26333f"];

  for (const [index, scene] of metadata.scenes.entries()) {
    const imagePath =
      scene.imageIndex === null ? undefined : files.images[scene.imageIndex];
    if (imagePath) {
      inputArgs.push(
        "-loop",
        "1",
        "-framerate",
        "24",
        "-t",
        String(scene.durationSeconds),
        "-i",
        imagePath,
      );
    } else {
      const background = palette[index % palette.length];
      inputArgs.push(
        "-f",
        "lavfi",
        "-i",
        `color=c=${background}:s=${width}x${height}:r=24:d=${scene.durationSeconds}`,
      );
    }
    const captionPath = join(record.directory, `caption-${index}.txt`);
    await writeFile(captionPath, scene.caption.trim(), "utf8");
    const label = `scene${index}`;
    sceneLabels.push(label);
    const fontSize = Math.round(width * 0.055);
    filterParts.push(
      `[${index}:v]scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height},zoompan=z='min(zoom+0.0005,1.10)':d=1:s=${width}x${height}:fps=24,drawtext=textfile='${escapeFilterPath(captionPath)}':font='DejaVu Sans':fontcolor=white:fontsize=${fontSize}:x=(w-text_w)/2:y=h-text_h-90:box=1:boxcolor=black@0.48:boxborderw=24,settb=AVTB,setpts=PTS-STARTPTS,format=yuv420p[${label}]`,
    );
    if (index < metadata.scenes.length - 1) {
      transitionDurations.push(
        Math.min(
          TRANSITION_SECONDS,
          scene.durationSeconds / 3,
          metadata.scenes[index + 1].durationSeconds / 3,
        ),
      );
    }
  }

  const subtitlePath = join(record.directory, "captions.srt");
  let subtitleCursor = 0;
  const subtitleEntries = metadata.scenes.map((scene, index) => {
    const start = subtitleCursor;
    const isLast = index === metadata.scenes.length - 1;
    const transition = isLast ? 0 : transitionDurations[index];
    const end = isLast
      ? metadata.durationSeconds
      : start + scene.durationSeconds - transition;
    subtitleCursor = end;
    return `${index + 1}\n${formatSrtTime(start)} --> ${formatSrtTime(end)}\n${scene.caption.replaceAll("-->", "—>")}\n`;
  });
  await writeFile(subtitlePath, `${subtitleEntries.join("\n")}\n`, "utf8");

  let currentLabel = sceneLabels[0];
  let elapsed = metadata.scenes[0].durationSeconds;
  for (let index = 1; index < sceneLabels.length; index += 1) {
    const nextLabel = `mix${index}`;
    const transition = transitionDurations[index - 1];
    const offset = Math.max(0, elapsed - transition);
    filterParts.push(
      `[${currentLabel}][${sceneLabels[index]}]xfade=transition=fade:duration=${transition}:offset=${offset.toFixed(3)}[${nextLabel}]`,
    );
    currentLabel = nextLabel;
    elapsed += metadata.scenes[index].durationSeconds - transition;
  }

  const padDuration = Math.max(0, metadata.durationSeconds - elapsed);
  filterParts.push(
    `[${currentLabel}]tpad=stop_mode=clone:stop_duration=${padDuration.toFixed(3)},trim=duration=${metadata.durationSeconds},setpts=PTS-STARTPTS[vout]`,
  );

  let narrationIndex: number | null = null;
  let musicIndex: number | null = null;
  let nextInputIndex = metadata.scenes.length;
  if (files.narration) {
    narrationIndex = nextInputIndex++;
    inputArgs.push("-i", files.narration);
  }
  if (files.music) {
    musicIndex = nextInputIndex++;
    inputArgs.push("-stream_loop", "-1", "-i", files.music);
  }
  const subtitleIndex = nextInputIndex;
  inputArgs.push("-i", subtitlePath);
  let audioMap: string[] = [];
  if (narrationIndex !== null && musicIndex !== null) {
    filterParts.push(
      `[${narrationIndex}:a]aresample=48000,apad,atrim=duration=${metadata.durationSeconds},volume=${metadata.narrationVolume ?? 1}[narr];[${musicIndex}:a]aresample=48000,atrim=duration=${metadata.durationSeconds},volume=${metadata.musicVolume ?? 0.16}[music];[narr][music]amix=inputs=2:duration=longest:dropout_transition=2:normalize=0,alimiter=limit=0.95[aout]`,
    );
    audioMap = ["-map", "[aout]", "-c:a", "aac", "-b:a", "128k"];
  } else if (narrationIndex !== null) {
    filterParts.push(
      `[${narrationIndex}:a]aresample=48000,apad,atrim=duration=${metadata.durationSeconds},volume=${metadata.narrationVolume ?? 1}[aout]`,
    );
    audioMap = ["-map", "[aout]", "-c:a", "aac", "-b:a", "128k"];
  } else if (musicIndex !== null) {
    filterParts.push(
      `[${musicIndex}:a]aresample=48000,atrim=duration=${metadata.durationSeconds},volume=${metadata.musicVolume ?? 0.16}[aout]`,
    );
    audioMap = ["-map", "[aout]", "-c:a", "aac", "-b:a", "128k"];
  }

  const ffmpegArgs = [
    ...inputArgs,
    "-filter_complex",
    filterParts.join(";"),
    "-map",
    "[vout]",
    "-map",
    `${subtitleIndex}:s:0`,
    "-c:s",
    "mov_text",
    ...audioMap,
    "-t",
    String(metadata.durationSeconds),
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-crf",
    "27",
    "-pix_fmt",
    "yuv420p",
    "-r",
    "24",
    "-map_metadata",
    "-1",
    "-movflags",
    "+faststart",
    "-progress",
    "pipe:1",
    "-nostats",
    outputPath,
  ];

  safeJobUpdate(jobId, {
    status: "running",
    stage: "rendering",
    message: "Rendering MP4 with FFmpeg",
    progress: 1,
  });
  await runFfmpeg(jobId, ffmpegArgs, metadata.durationSeconds);
  const verifiedDuration = await probeDuration(outputPath);
  const outputStat = await stat(outputPath);
  if (outputStat.size < 1024) {
    throw new Error("The MP4 output is unexpectedly small.");
  }
  safeJobUpdate(jobId, {
    status: "complete",
    stage: "ready",
    message: "MP4 rendered and verified.",
    progress: 100,
    durationSeconds: verifiedDuration,
    fileSizeBytes: outputStat.size,
    videoUrl: `/api/render-jobs/${jobId}/video`,
    error: null,
  });
}

function processRenderQueue(): void {
  if (isRendering) return;
  const jobId = renderQueue.shift();
  if (!jobId) return;
  isRendering = true;
  void renderOneJob(jobId)
    .catch((error: unknown) => {
      const reason = error instanceof Error ? error.message : "Unknown render error";
      logger.error({ jobId, error: reason }, "Video render failed");
      safeJobUpdate(jobId, {
        status: "failed",
        stage: "error",
        message: "The render failed. Check your media files and retry.",
        error: "FFmpeg could not complete this render. Try smaller files or a shorter video.",
      });
    })
    .finally(() => {
      isRendering = false;
      processRenderQueue();
    });
}

const cleanupTimer = setInterval(() => {
  const expiration = Date.now() - 60 * 60 * 1000;
  for (const [jobId, job] of renderJobs) {
    if (job.createdAt >= expiration || job.result.status === "queued" || job.result.status === "running") continue;
    renderJobs.delete(jobId);
    void rm(job.directory, { recursive: true, force: true });
  }
}, 5 * 60 * 1000);
cleanupTimer.unref();

const disclosure =
  "Built from reusable templates, not an AI model. Review and edit this starter before publishing.";

const sceneTemplates: Record<
  string,
  Array<{ narration: string; caption: string; visual: string }>
> = {
  English: [
    {
      narration: "Start with one clear idea: {topic}.",
      caption: "THE BIG IDEA",
      visual: "A clean opening visual that introduces {topic}",
    },
    {
      narration: "Here is the simple version: look at what it does, then why it matters.",
      caption: "KEEP IT SIMPLE",
      visual: "A simple visual metaphor for the main idea",
    },
    {
      narration: "The detail people often miss is how the small parts connect.",
      caption: "THE DETAIL THAT MATTERS",
      visual: "A close-up illustration showing connected parts",
    },
    {
      narration: "Picture {topic} in everyday life. The idea becomes easier to see.",
      caption: "MAKE IT CONCRETE",
      visual: "An everyday example related to {topic}",
    },
    {
      narration: "So remember this: one useful takeaway can change how you see the whole subject.",
      caption: "ONE TAKEAWAY",
      visual: "A memorable summary image with one focal point",
    },
    {
      narration: "Now you have a starting point. What would you add?",
      caption: "YOUR TURN",
      visual: "A simple closing frame that invites reflection",
    },
  ],
  Hindi: [
    {
      narration: "शुरुआत एक आसान विचार से करें: {topic}।",
      caption: "मुख्य विचार",
      visual: "{topic} को पेश करता हुआ एक साफ़ शुरुआती दृश्य",
    },
    {
      narration: "इसे सरल रखें: पहले समझें कि यह क्या करता है, फिर यह क्यों मायने रखता है।",
      caption: "सरल रखें",
      visual: "मुख्य विचार को समझाने वाला सरल दृश्य रूपक",
    },
    {
      narration: "एक ज़रूरी बात अक्सर छूट जाती है: छोटे हिस्से मिलकर बड़ी तस्वीर बनाते हैं।",
      caption: "ज़रूरी बात",
      visual: "जुड़े हुए हिस्सों का पास से बना चित्र",
    },
    {
      narration: "रोज़मर्रा की ज़िंदगी में {topic} की कल्पना करें। बात और साफ़ हो जाती है।",
      caption: "उदाहरण से समझें",
      visual: "{topic} से जुड़ा रोज़मर्रा का उदाहरण",
    },
    {
      narration: "यह याद रखें: एक काम की बात पूरे विषय को देखने का नज़रिया बदल सकती है।",
      caption: "एक सीख",
      visual: "एक मुख्य बिंदु वाला यादगार सारांश दृश्य",
    },
    {
      narration: "अब आपके पास शुरुआत करने का तरीका है। आप क्या जोड़ेंगे?",
      caption: "आपकी बारी",
      visual: "सोचने के लिए आमंत्रित करता हुआ सरल अंतिम दृश्य",
    },
  ],
  Spanish: [
    {
      narration: "Empecemos con una idea clara: {topic}.",
      caption: "LA GRAN IDEA",
      visual: "Una imagen inicial clara que presenta {topic}",
    },
    {
      narration: "La versión sencilla: mira qué hace y después por qué importa.",
      caption: "MANTÉNLO SIMPLE",
      visual: "Una metáfora visual sencilla para la idea principal",
    },
    {
      narration: "A menudo se pasa por alto un detalle: las partes pequeñas se conectan.",
      caption: "EL DETALLE CLAVE",
      visual: "Una ilustración cercana que muestra partes conectadas",
    },
    {
      narration: "Imagina {topic} en la vida diaria. La idea se vuelve más clara.",
      caption: "UN EJEMPLO CONCRETO",
      visual: "Un ejemplo cotidiano relacionado con {topic}",
    },
    {
      narration: "Recuerda esto: una conclusión útil puede cambiar cómo ves todo el tema.",
      caption: "UNA CONCLUSIÓN",
      visual: "Una imagen de resumen memorable con un solo punto focal",
    },
    {
      narration: "Ya tienes un punto de partida. ¿Qué añadirías?",
      caption: "TE TOCA",
      visual: "Un cierre sencillo que invite a reflexionar",
    },
  ],
};

const styleDescriptions: Record<string, string> = {
  Cinematic: "Cinematic lighting and composition",
  Realistic: "Photorealistic details",
  Anime: "Expressive anime illustration",
  Illustration: "Editorial illustration",
  Minimal: "Minimal shapes and clean composition",
};

router.get("/capabilities", (_req, res) => {
  const data = GetCapabilitiesResponse.parse({
    scriptGeneration: "Built-in reusable templates; no AI model is connected.",
    imageGeneration: "Upload your own images; automatic image generation is not available.",
    narration: "Upload your own narration; automatic text-to-speech is not available.",
    rendering: "MP4 rendering uses FFmpeg on this server. Render files are temporary.",
    storage: "Project drafts are stored in this browser. Server-side render jobs are temporary.",
    notice:
      "No paid inference or media API is used. This demo does not claim template text or uploaded assets were AI-generated.",
  });
  res.json(data);
});

router.post("/drafts", (req, res) => {
  const parsed = CreateDraftBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { topic, durationSeconds, aspectRatio, language, visualStyle } =
    parsed.data;
  const cleanTopic = topic.trim();
  const title = parsed.data.title?.trim() || cleanTopic.slice(0, 80);
  const templates = sceneTemplates[language] ?? sceneTemplates.English;
  const sceneCount = Math.min(6, Math.max(3, Math.ceil(durationSeconds / 10)));
  const durationPerScene = durationSeconds / sceneCount;
  const scenes = templates.slice(0, sceneCount).map((template, index) => ({
    id: randomUUID(),
    order: index + 1,
    narration: template.narration.replaceAll("{topic}", cleanTopic),
    caption: template.caption,
    imagePrompt: `${styleDescriptions[visualStyle] ?? "Simple composition"}: ${template.visual.replaceAll("{topic}", cleanTopic)}`,
    durationSeconds: durationPerScene,
  }));
  const script = scenes.map((scene) => scene.narration).join(" ");
  const result = CreateDraftResponse.parse({
    id: randomUUID(),
    title,
    topic: cleanTopic,
    hook: scenes[0]?.narration ?? cleanTopic,
    script,
    durationSeconds,
    aspectRatio,
    language,
    visualStyle,
    scenes,
    generationMode: "template",
    disclosure,
  });

  res.status(201).json(result);
});

router.post("/render-jobs", parseRenderUpload, async (req, res): Promise<void> => {
  const directory = (req as RequestWithRenderDirectory).renderDirectory;
  if (!directory) {
    res.status(500).json({ error: "Could not prepare a temporary render folder." });
    return;
  }

  const uploaded = (req.files ?? {}) as Record<string, Express.Multer.File[]>;
  const images = uploaded.images ?? [];
  const narration = uploaded.narration?.[0];
  const music = uploaded.music?.[0];
  const allMedia = [...images, ...(narration ? [narration] : []), ...(music ? [music] : [])];
  const totalBytes = allMedia.reduce((total, file) => total + file.size, 0);

  if (
    images.some((file) => file.size > MAX_IMAGE_BYTES) ||
    (narration && narration.size > MAX_AUDIO_BYTES) ||
    (music && music.size > MAX_AUDIO_BYTES) ||
    totalBytes > 36 * 1024 * 1024
  ) {
    await rm(directory, { recursive: true, force: true });
    res.status(400).json({
      error: "Media is over the demo limit: 8 MB per image, 12 MB per audio file, and 36 MB total.",
    });
    return;
  }

  const metadata = parseRenderMetadata(req.body.metadata, images.length);
  if (!metadata) {
    await rm(directory, { recursive: true, force: true });
    res.status(400).json({ error: "Render metadata is invalid or scene timing does not match the selected duration." });
    return;
  }

  for (const image of images) {
    if (!(await hasValidMediaSignature(image, "image"))) {
      await rm(directory, { recursive: true, force: true });
      res.status(400).json({ error: "An uploaded image is not a valid PNG, JPEG, or WebP file." });
      return;
    }
  }
  for (const audio of [narration, music]) {
    if (audio && !(await hasValidMediaSignature(audio, "audio"))) {
      await rm(directory, { recursive: true, force: true });
      res.status(400).json({ error: "An uploaded audio file could not be identified. Try MP3, WAV, AAC, M4A, or OGG." });
      return;
    }
  }

  const busyCount = renderQueue.length + (isRendering ? 1 : 0);
  if (busyCount >= MAX_QUEUED_JOBS) {
    await rm(directory, { recursive: true, force: true });
    res.status(429).json({ error: "The free demo render queue is full. Wait for a current job to finish, then retry." });
    return;
  }

  const jobId = randomUUID();
  await writeFile(join(directory, "metadata.json"), JSON.stringify(metadata), "utf8");
  await writeFile(
    join(directory, "uploads.json"),
    JSON.stringify({
      images: images.map((file) => file.path),
      narration: narration?.path ?? null,
      music: music?.path ?? null,
    }),
    "utf8",
  );

  const result = CreateRenderJobResponse.parse({
    id: jobId,
    status: "queued",
    stage: "queued",
    message: "Waiting for the local FFmpeg render slot.",
    progress: 0,
    durationSeconds: null,
    fileSizeBytes: null,
    videoUrl: null,
    error: null,
  });
  renderJobs.set(jobId, { result, directory, createdAt: Date.now() });
  renderQueue.push(jobId);
  res.status(202).json(result);
  processRenderQueue();
});

router.get("/render-jobs/:jobId", (req, res) => {
  const parsed = GetRenderJobParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid render job ID." });
    return;
  }
  const job = renderJobs.get(parsed.data.jobId);
  if (!job) {
    res.status(404).json({ error: "Render job was not found. Jobs are temporary and expire after one hour." });
    return;
  }
  res.json(GetRenderJobResponse.parse(job.result));
});

router.get("/render-jobs/:jobId/video", async (req, res): Promise<void> => {
  const parsed = GetRenderJobParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid render job ID." });
    return;
  }
  const job = renderJobs.get(parsed.data.jobId);
  if (!job || job.result.status !== "complete") {
    res.status(404).json({ error: "The verified MP4 is not available." });
    return;
  }
  const outputPath = join(job.directory, "render.mp4");
  try {
    await stat(outputPath);
  } catch {
    res.status(404).json({ error: "The temporary MP4 has expired." });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.download(outputPath, `reelforge-${job.result.id}.mp4`);
});

export default router;