import { Router, type IRouter } from "express";
import healthRouter from "./health";
import draftsRouter from "./drafts";

const router: IRouter = Router();

router.use(healthRouter);
router.use(draftsRouter);

export default router;
