# ReelForge AI

An editable short-video starter with deterministic script templates, user-supplied media, and server-side FFmpeg MP4 rendering.

## Current capabilities

- English, Hindi, or Spanish starter scripts built from reusable templates—not an AI model.
- Editable scripts and scene captions, still-image uploads, and browser-local project metadata.
- Optional uploaded narration and licensed music mixed into MP4 with adjustable levels.
- FFmpeg output with transitions, visible captions, and a selectable timed subtitle track.
- Live render status, an in-app MP4 preview, and a download link.

No AI, text-to-speech, image-generation, or paid media API is connected. The app does not claim that template text or uploaded assets are generated.

## Limits and storage

- Project metadata stays in this browser's local storage and does not sync to other devices.
- Uploaded media stays in the current editing session until a render is requested. The render request sends the selected files to the API service.
- The API holds uploaded media and render jobs in temporary storage. Jobs are kept for about one hour while the service is running; a restart can discard them earlier.
- Render limits: 15, 30, 45, or 60 seconds; up to six still images; 8 MB per image; 12 MB per audio file; 36 MB total; one render at a time with up to three active/queued jobs.
- Supported uploads: PNG/JPEG/WebP stills and MP3/WAV/AAC/M4A/OGG audio.
- Captions are timed by scene, not aligned to individual spoken words.

## Run and verify

The workspace provides managed workflows for the web app and API service. The API runtime needs `ffmpeg` and `ffprobe` with H.264/AAC and MP4 subtitle support. No API key is required by the current implementation.

Useful commands:

```sh
pnpm --filter @workspace/api-spec run codegen
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/reelforge-ai run typecheck
```

The development runtime has been checked for FFmpeg availability. Verify the deployment runtime separately before publishing; this app does not promise that a hosting plan provides free compute, persistent storage, or FFmpeg.