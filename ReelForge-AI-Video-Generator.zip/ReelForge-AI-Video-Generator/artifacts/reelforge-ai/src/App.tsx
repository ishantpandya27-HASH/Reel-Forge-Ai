import { type FormEvent, type MouseEvent, type ReactNode, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { getHealthCheckQueryKey, getGetCapabilitiesQueryKey, getGetRenderJobQueryKey, getDownloadRenderedVideoUrl, useHealthCheck, useGetCapabilities, useCreateDraft, useCreateRenderJob, useGetRenderJob } from '@workspace/api-client-react';
import type { DraftInput, RenderMetadata, RenderJobForm, VideoDraft } from '@workspace/api-client-react';
import { ArrowDownToLine, ArrowRight, AudioLines, Check, ChevronRight, CircleAlert, Clapperboard, Clock3, Film, House, Image, LoaderCircle, Music2, Play, Plus, Settings2, ShieldCheck, Sparkles, Upload, WandSparkles, X } from 'lucide-react';
import { Link, Route, Switch, useLocation, useParams, Router as WouterRouter } from 'wouter';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const STORAGE_KEY = 'reelforge.projects.v1';

type DraftScene = VideoDraft['scenes'][number];
type LocalProject = VideoDraft & { savedAt: string; updatedAt: string; renderJobId?: string };

function readProjects(): LocalProject[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(parsed) ? parsed as LocalProject[] : [];
  } catch {
    return [];
  }
}
function saveProjects(projects: LocalProject[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
    return true;
  } catch {
    return false;
  }
}
function persistProject(project: LocalProject) {
  const projects = readProjects();
  const updated = [project, ...projects.filter((item) => item.id !== project.id)];
  return saveProjects(updated.slice(0, 30));
}
function loadProject(id: string) { return readProjects().find((project) => project.id === id); }
function formatTime(seconds: number) { return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`; }

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const routes = [
    { href: '/', label: 'Dashboard', icon: House },
    { href: '/create', label: 'New video', icon: Plus },
    { href: '/settings', label: 'Settings', icon: Settings2 },
  ];
  const current = location === '/' ? 'Studio' : location.startsWith('/project/') ? 'Editor' : location === '/create' ? 'New video' : 'Settings';
  return <div className="app-shell">
    <aside className="sidebar">
      <Link href="/" className="brand" data-testid="link-brand">
        <span className="brand-mark"><Film size={19} strokeWidth={2.2}/></span>
        <span className="brand-name">ReelForge <span className="brand-ai">AI</span></span>
      </Link>
      <div className="side-label">Your workspace</div>
      <nav className="nav-stack" aria-label="Main navigation">
        {routes.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`nav-link${location === href ? ' active' : ''}`} data-testid={`link-nav-${label.toLowerCase().replace(' ', '-')}`}>
          <Icon size={16}/><span>{label}</span>
        </Link>)}
      </nav>
      <div className="side-bottom">
        <div className="side-label">Made for makers</div>
        <div className="local-note"><strong><ShieldCheck size={13} style={{ display: 'inline', marginRight: 5, verticalAlign: '-2px' }}/>Private by default</strong>Drafts stay in this browser. Media is sent to the render service only when you request an MP4.</div>
      </div>
    </aside>
    <main className="main-area">
      <div className="topbar">
        <div className="crumb"><span>ReelForge</span><ChevronRight size={12}/><strong>{current}</strong></div>
        <div className="top-right"><span className="status-dot"/><span>Local studio</span></div>
      </div>
      {children}
    </main>
  </div>;
}

function ApiStatus() {
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), retry: 1, staleTime: 30000 } });
  const caps = useGetCapabilities({ query: { queryKey: getGetCapabilitiesQueryKey(), retry: 1, staleTime: 30000 } });
  return <div className="status-grid">
    <div className="status-card">
      <div className="status-top"><span>Template script service</span><span className={`status-badge ${health.isError ? 'offline' : ''}`}>{health.isLoading ? 'CHECKING' : health.isError ? 'UNAVAILABLE' : 'CONNECTED'}</span></div>
      <div className="status-name">{health.isLoading ? 'Checking service…' : health.isError ? 'Service not reachable' : 'Ready for a first draft'}</div>
      <div className="status-detail">{health.isError ? <>Reconnect to the project API to create a starter script. Your saved projects remain available. <button className="upload-action" onClick={() => health.refetch()} data-testid="button-retry-health">Retry</button></> : 'Uses deterministic template text, not a hosted AI model.'}</div>
    </div>
    <div className="status-card">
      <div className="status-top"><span>Hosted AI generation</span><span className="status-badge offline">NOT INCLUDED</span></div>
      <div className="status-name">No paid model connected</div>
      <div className="status-detail">Script drafts are clearly labeled template-generated. Image generation is not available.</div>
    </div>
    <div className="status-card">
      <div className="status-top"><span>This-browser workspace</span><span className="status-badge">AVAILABLE</span></div>
      <div className="status-name">{caps.isLoading ? 'Checking capabilities…' : 'Local editing & saving'}</div>
      <div className="status-detail">{caps.data?.storage || 'Project metadata saves in this browser. Uploaded media is never represented as generated.'}</div>
    </div>
  </div>;
}

function Dashboard() {
  const [projects, setProjects] = useState<LocalProject[]>(() => readProjects());
  const [storageError, setStorageError] = useState('');
  useEffect(() => {
    const refresh = () => setProjects(readProjects());
    window.addEventListener('storage', refresh);
    return () => window.removeEventListener('storage', refresh);
  }, []);
  function removeProject(event: MouseEvent, id: string) {
    event.preventDefault(); event.stopPropagation();
    if (!window.confirm('Delete this project from this browser? This cannot be undone.')) return;
    const next = readProjects().filter((project) => project.id !== id);
    if (!saveProjects(next)) setStorageError('This browser could not update local storage. Check available space or browser privacy settings.');
    setProjects(next);
  }
  return <div className="page fade-in">
    <section className="hero-panel">
      <div className="hero-copy">
        <div className="eyebrow"><Sparkles size={13}/> Your ideas, in sequence</div>
        <h1>Make a short worth stopping for.</h1>
        <p>Shape a topic into an editable storyboard. Bring your own visuals and sound, then preview a rendered MP4.</p>
        <Link href="/create" className="btn btn-primary" data-testid="button-create-video">Start a video <ArrowRight size={14}/></Link>
      </div>
      <div className="hero-art" aria-hidden="true"><div className="film-frame back"/><div className="film-frame"/></div>
    </section>
    <div className="section-head"><div><h2>Studio status</h2><p>A straight answer about what works right now.</p></div></div>
    <ApiStatus/>
    <div className="section-head"><div><h2>Your projects <span style={{ color: 'hsl(var(--muted-foreground))', fontWeight: 500 }}>({projects.length})</span></h2><p>Saved to this browser only.</p></div>
      {projects.length > 0 && <Link href="/create" className="btn btn-secondary" data-testid="button-new-project"><Plus size={14}/> New project</Link>}
    </div>
    {storageError && <div className="error-box" role="alert">{storageError}</div>}
    {projects.length ? <div className="project-grid">
      {projects.map((project, index) => <div key={project.id} className="card project-card" data-testid={`card-project-${project.id}`}>
        <Link href={`/project/${encodeURIComponent(project.id)}`} style={{ color: 'inherit', textDecoration: 'none', display: 'block' }} data-testid={`link-project-${project.id}`}>
          <div className={`project-art art-${index % 3}`}><span className="art-label">{project.visualStyle} / {project.aspectRatio}</span></div>
          <div className="project-info">
            <div className="project-name">{project.title || project.topic}</div>
            <div className="project-meta"><span>{project.durationSeconds}s · {project.scenes.length} scenes</span><span>Open project</span></div>
          </div>
        </Link>
        <div style={{ padding: '0 14px 12px', textAlign: 'right' }}><button className="upload-action" onClick={(event) => removeProject(event, project.id)} data-testid={`button-delete-project-${project.id}`} aria-label={`Delete ${project.title}`}>Delete project</button></div>
      </div>)}
    </div> : <div className="empty-state">
      <div className="empty-icon"><Clapperboard size={20}/></div><h3>Your next video starts with a topic.</h3>
      <p>Drafts you create appear here and stay in this browser. No account or publishing step required.</p>
      <Link href="/create" className="btn btn-primary" data-testid="button-empty-create"><Plus size={14}/> Create your first video</Link>
    </div>}
  </div>;
}

const languages = ['English', 'Hindi', 'Spanish'] as const;
const durations = [15, 30, 45, 60] as const;
const ratios = ['9:16', '16:9', '1:1'] as const;
const styles = ['Cinematic', 'Realistic', 'Anime', 'Illustration', 'Minimal'] as const;

function ChoiceGroup<T extends string | number>({ value, options, onChange, label }: { value: T; options: readonly T[]; onChange: (value: T) => void; label: string }) {
  return <div className="option-row" role="group" aria-label={label}>{options.map((option) => <button type="button" key={option} onClick={() => onChange(option)} className={`choice${value === option ? ' selected' : ''}`} aria-pressed={value === option} data-testid={`choice-${label.toLowerCase().replaceAll(' ', '-')}-${String(option).replace(':', '-')}`}>{option}{typeof option === 'number' ? ' sec' : ''}</button>)}</div>;
}

function CreatePage() {
  const [, navigate] = useLocation();
  const createDraft = useCreateDraft();
  const [topic, setTopic] = useState('');
  const [title, setTitle] = useState('');
  const [language, setLanguage] = useState<DraftInput['language']>('English');
  const [durationSeconds, setDuration] = useState<DraftInput['durationSeconds']>(30);
  const [aspectRatio, setRatio] = useState<DraftInput['aspectRatio']>('9:16');
  const [visualStyle, setStyle] = useState<DraftInput['visualStyle']>('Cinematic');
  const [error, setError] = useState('');
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError('');
    const cleanTopic = topic.trim();
    if (cleanTopic.length < 8) { setError('Add a little more detail: your topic needs at least 8 characters.'); return; }
    if (title.trim().length > 100) { setError('Keep the title under 100 characters.'); return; }
    const input: DraftInput = { topic: cleanTopic, title: title.trim() || undefined, language, durationSeconds, aspectRatio, visualStyle };
    createDraft.mutate({ data: input }, {
      onSuccess: (draft) => {
        const now = new Date().toISOString();
        const local: LocalProject = { ...draft, savedAt: now, updatedAt: now };
        if (!persistProject(local)) setError('The script was created, but this browser could not save it. Free up local storage and try again.');
        navigate(`/project/${encodeURIComponent(draft.id)}`);
      },
      onError: () => setError('The template service could not create a draft just now. Your topic is still here. Check the service status and try again.'),
    });
  }
  return <div className="page fade-in">
    <div className="eyebrow"><WandSparkles size={13}/> Script starter</div>
    <h1 className="page-title">Give your idea a shape.</h1>
    <p className="page-subtitle">Get a useful, editable starting point for your short. No claims of AI generation: this uses a deterministic text template.</p>
    <form onSubmit={submit} className="form-layout">
      <div className="card form-card">
        <h2 className="form-section-title">01 / The idea</h2>
        <div className="field"><label htmlFor="video-topic">What is your video about?</label>
          <textarea id="video-topic" className="control" value={topic} onChange={(event) => setTopic(event.target.value)} placeholder="For example: why city trees can lower summer street temperatures" maxLength={500} required data-testid="input-video-topic"/>
          <div className="field-hint">Be specific about the takeaway or audience. 8–500 characters.</div>
        </div>
        <div className="field"><label htmlFor="video-title">Working title <span style={{ color: 'hsl(var(--muted-foreground))', fontWeight: 500 }}>· optional</span></label>
          <input id="video-title" className="control" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Give this idea a name" maxLength={100} data-testid="input-video-title"/>
        </div>
        <div style={{ borderTop: '1px solid hsl(var(--border))', paddingTop: 20, marginTop: 4 }}>
          <h2 className="form-section-title">02 / The format</h2>
          <div className="field"><span className="field-label">Language</span><ChoiceGroup<DraftInput['language']> value={language} options={languages} onChange={setLanguage} label="Language"/></div>
          <div className="field"><span className="field-label">Target duration</span><ChoiceGroup<DraftInput['durationSeconds']> value={durationSeconds} options={durations} onChange={setDuration} label="Duration"/></div>
          <div className="field"><span className="field-label">Frame ratio</span><ChoiceGroup<DraftInput['aspectRatio']> value={aspectRatio} options={ratios} onChange={setRatio} label="Aspect ratio"/></div>
          <div className="field" style={{ marginBottom: 4 }}><span className="field-label">Visual direction</span><ChoiceGroup<DraftInput['visualStyle']> value={visualStyle} options={styles} onChange={setStyle} label="Visual style"/></div>
        </div>
        {error && <div className="error-box" role="alert" data-testid="status-create-error">{error}</div>}
        <button type="submit" className="btn btn-primary" disabled={createDraft.isPending} data-testid="button-generate-draft">
          {createDraft.isPending ? <><LoaderCircle size={14} className="spin"/> Building your starter…</> : <><WandSparkles size={14}/> Create editable script</>}
        </button>
      </div>
      <aside className="card form-side">
        <div className="side-heading"><ShieldCheck size={16} color="hsl(var(--primary))"/> Clear by design</div>
        <p className="side-copy">A starter is a beginning, not a finished video. The returned words come from a no-cost template service, not an AI model.</p>
        <div className="mini-row"><Check size={13} className="mini-check"/>Every line stays editable</div>
        <div className="mini-row"><Check size={13} className="mini-check"/>Bring your own licensed media</div>
        <div className="mini-row"><Check size={13} className="mini-check"/>Saved to this browser</div>
        <div className="note-box">Image generation, hosted narration, and paid AI providers are not connected. Image prompts are creative direction only.</div>
      </aside>
    </form>
  </div>;
}

function UploadControl({ label, detail, accept, icon: Icon, fileName, onFile, testId }: { label: string; detail: string; accept: string; icon: typeof Image; fileName: string; onFile: (file: File | null) => void; testId: string }) {
  const ref = useRef<HTMLInputElement>(null);
  return <div className="upload-row">
    <div><div className="upload-label"><Icon size={14}/>{label}</div><div className="upload-info">{fileName || detail}</div></div>
    <input ref={ref} className="hidden-input" type="file" accept={accept} onChange={(event) => onFile(event.target.files?.[0] || null)} data-testid={`input-${testId}`}/>
    <button type="button" className="upload-action" onClick={() => ref.current?.click()} data-testid={`button-upload-${testId}`}>{fileName ? 'Replace' : 'Choose file'}</button>
  </div>;
}

function ProjectPage() {
  const params = useParams<{ id: string }>();
  const id = decodeURIComponent(params.id || '');
  const [, navigate] = useLocation();
  const [project, setProject] = useState<LocalProject | null>(() => loadProject(id) || null);
  const [script, setScript] = useState('');
  const [scenes, setScenes] = useState<DraftScene[]>([]);
  const [media, setMedia] = useState<Record<string, string>>({});
  const [mediaNames, setMediaNames] = useState<Record<string, string>>({});
  const [mediaFiles, setMediaFiles] = useState<Record<string, File>>({});
  const [renderJobId, setRenderJobId] = useState(() => loadProject(id)?.renderJobId || '');
  const [notice, setNotice] = useState('');
  const [previewing, setPreviewing] = useState(false);
  const [previewIndex, setPreviewIndex] = useState(0);
  const [narrationVolume, setNarrationVolume] = useState(1);
  const [musicVolume, setMusicVolume] = useState(0.16);
  const createRenderJob = useCreateRenderJob();
  const renderQuery = useGetRenderJob(renderJobId || '', {
    query: {
      queryKey: getGetRenderJobQueryKey(renderJobId || ''),
      enabled: Boolean(renderJobId),
      refetchInterval: (query) => {
        const status = query.state.data?.status;
        return status === 'queued' || status === 'running' ? 2600 : false;
      },
    },
  });
  const renderedVideoUrl = renderQuery.data?.status === 'complete'
    ? getDownloadRenderedVideoUrl(renderJobId)
    : '';
  useEffect(() => {
    const found = loadProject(id);
    if (found) { setProject(found); setScript(found.script); setScenes(found.scenes); setRenderJobId(found.renderJobId || ''); }
  }, [id]);
  useEffect(() => {
    if (!previewing || scenes.length < 2) return;
    const timer = window.setInterval(() => setPreviewIndex((current) => (current + 1) % scenes.length), 1800);
    return () => window.clearInterval(timer);
  }, [previewing, scenes.length]);
  const mediaRef = useRef(media);
  mediaRef.current = media;
  useEffect(() => () => { Object.values(mediaRef.current).forEach((url) => URL.revokeObjectURL(url)); }, []);
  function saveEdits(nextScript = script, nextScenes = scenes) {
    if (!project) return;
    const updated = { ...project, script: nextScript, scenes: nextScenes, updatedAt: new Date().toISOString() };
    setProject(updated);
    if (persistProject(updated)) setNotice('Saved in this browser');
    else setNotice('Could not save: browser storage may be full');
    window.setTimeout(() => setNotice(''), 2600);
  }
  function setSceneField(sceneId: string, key: 'narration' | 'caption', value: string) {
    const next = scenes.map((scene) => scene.id === sceneId ? { ...scene, [key]: value } : scene);
    setScenes(next);
    saveEdits(script, next);
  }
  function setScriptValue(value: string) { setScript(value); saveEdits(value, scenes); }
  function attachFile(key: string, file: File | null) {
    if (!file) return;
    const isImage = key.startsWith('scene-');
    const allowedTypes = isImage
      ? ['image/jpeg', 'image/png', 'image/webp']
      : ['audio/mpeg', 'audio/mp4', 'audio/x-m4a', 'audio/aac', 'audio/wav', 'audio/x-wav', 'audio/ogg'];
    const maxBytes = isImage ? 8 * 1024 * 1024 : 12 * 1024 * 1024;
    if (!allowedTypes.includes(file.type)) {
      setNotice(isImage ? 'Use a PNG, JPEG, or WebP still image.' : 'Use an MP3, WAV, AAC, M4A, or OGG audio file.');
      return;
    }
    if (file.size > maxBytes) {
      setNotice(`That file exceeds the ${isImage ? '8 MB image' : '12 MB audio'} limit. Choose a smaller file.`);
      return;
    }
    const nextUrls = { ...media };
    if (nextUrls[key]) URL.revokeObjectURL(nextUrls[key]);
    const url = URL.createObjectURL(file);
    nextUrls[key] = url;
    setMedia(nextUrls); setMediaNames((old) => ({ ...old, [key]: file.name }));
    setMediaFiles((old) => ({ ...old, [key]: file }));
    setNotice('Media added for this editing session');
    window.setTimeout(() => setNotice(''), 2600);
  }
  function queueMp4Render() {
    if (!project || scenes.length === 0) return;
    setNotice('');
    const totalUploadBytes = Object.values(mediaFiles).reduce((total, file) => total + file.size, 0);
    if (totalUploadBytes > 36 * 1024 * 1024) {
      setNotice('Selected media exceeds the 36 MB total limit. Remove or replace a file, then retry.');
      return;
    }
    const imageEntries = scenes.map((scene) => mediaFiles[`scene-${scene.id}`]).filter((file): file is File => Boolean(file));
    let nextImageIndex = 0;
    const renderScenes: RenderMetadata['scenes'] = scenes.map((scene) => {
      const image = mediaFiles[`scene-${scene.id}`];
      let imageIndex: number | null = null;
      if (image) { imageIndex = nextImageIndex; nextImageIndex += 1; }
      return {
        order: scene.order,
        durationSeconds: Math.min(60, Math.max(0.25, scene.durationSeconds)),
        caption: scene.caption.slice(0, 160),
        imageIndex,
      };
    });
    const metadata: RenderMetadata = {
      title: (project.title || project.topic).slice(0, 100),
      durationSeconds: project.durationSeconds as RenderMetadata['durationSeconds'],
      aspectRatio: project.aspectRatio as RenderMetadata['aspectRatio'],
      scenes: renderScenes,
      narrationVolume,
      musicVolume,
    };
    const payload: RenderJobForm = {
      metadata: JSON.stringify(metadata),
      ...(imageEntries.length ? { images: imageEntries } : {}),
      ...(mediaFiles.narration ? { narration: mediaFiles.narration } : {}),
      ...(mediaFiles.music ? { music: mediaFiles.music } : {}),
    };
    createRenderJob.mutate({ data: payload }, {
      onSuccess: (job) => {
        setRenderJobId(job.id);
        const updated = { ...project, renderJobId: job.id, updatedAt: new Date().toISOString() };
        setProject(updated);
        if (!persistProject(updated)) setNotice('Render queued. Job ID could not be saved in this browser.');
        else setNotice('Render queued. Progress updates from the render service.');
      },
      onError: () => setNotice('Could not queue the MP4 render. Check your connection and retry.'),
    });
  }
  if (!project) return <div className="page fade-in"><div className="empty-state"><div className="empty-icon"><CircleAlert size={20}/></div><h3>This project is not in this browser.</h3><p>It may have been removed, or you may be using a different browser profile. Projects are stored locally and are not synced.</p><Link href="/" className="btn btn-primary" data-testid="link-return-dashboard">Back to dashboard</Link></div></div>;
  const previewScene = scenes[previewIndex] || scenes[0];
  const heroImage = previewScene ? media[`scene-${previewScene.id}`] : undefined;
  return <div className="page fade-in">
    <div className="eyebrow"><Clapperboard size={13}/> Storyboard editor <span style={{ color: 'hsl(var(--muted-foreground))' }}>· template draft</span></div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 15, flexWrap: 'wrap' }}>
      <div><h1 className="page-title">{project.title || project.topic}</h1><p className="page-subtitle">{project.durationSeconds}s · {project.aspectRatio} · {project.language} · {project.visualStyle} · saved in this browser</p></div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        {notice && <span style={{ fontSize: 9, color: 'hsl(var(--muted-foreground))' }} role="status" data-testid="status-save-notice">{notice}</span>}
        <button className="btn btn-secondary" onClick={() => saveEdits()} data-testid="button-save-project"><Check size={13}/> Save</button>
      </div>
    </div>
    <div className="workspace">
      <div className="workspace-main">
        <section className="card editor-card">
          <div className="editor-header"><h2>Script draft</h2><span>EDITABLE · TEMPLATE-GENERATED</span></div>
          <textarea className="control script-area" value={script} onChange={(event) => setScriptValue(event.target.value)} aria-label="Editable script draft" data-testid="input-edit-script"/>
          <div className="field-hint">These starter lines are template-generated. Edit them to match your voice before recording.</div>
        </section>
        <section>
          <div className="section-head" style={{ margin: '3px 0 11px' }}><div><h2>Storyboard <span style={{ color: 'hsl(var(--muted-foreground))', fontWeight: 500 }}>({scenes.length} scenes)</span></h2><p>Prompts are suggestions, not generated images.</p></div></div>
          <div className="storyboard">
            {scenes.map((scene) => <article className="card scene-card" key={scene.id} data-testid={`card-scene-${scene.id}`}>
              <div className="scene-number">{String(scene.order).padStart(2, '0')}</div>
              <div>
                <div className="scene-top"><strong>Scene {scene.order}</strong><span><Clock3 size={10} style={{ display: 'inline', verticalAlign: '-1px' }}/> {scene.durationSeconds}s</span></div>
                <p className="scene-prompt">{scene.imagePrompt}</p>
                <div className="field" style={{ margin: '8px 0' }}><label className="field-label" htmlFor={`narration-${scene.id}`}>Narration</label><textarea className="control" id={`narration-${scene.id}`} rows={2} value={scene.narration} onChange={(event) => setSceneField(scene.id, 'narration', event.target.value)} data-testid={`input-narration-${scene.id}`}/></div>
                <div className="field" style={{ marginBottom: 0 }}><label className="field-label" htmlFor={`caption-${scene.id}`}>On-screen caption</label><input className="control" id={`caption-${scene.id}`} value={scene.caption} maxLength={160} onChange={(event) => setSceneField(scene.id, 'caption', event.target.value)} data-testid={`input-caption-${scene.id}`}/></div>
                <UploadControl label="Your still image" detail="Not generated · upload your own image (8 MB max)" accept="image/png,image/jpeg,image/webp" icon={Image} fileName={mediaNames[`scene-${scene.id}`] || ''} onFile={(file) => attachFile(`scene-${scene.id}`, file)} testId={`scene-${scene.id}`}/>
              </div>
            </article>)}
          </div>
        </section>
      </div>
      <aside>
        <section className="card editor-card">
          <div className="editor-header"><h2>Preview</h2><span>BROWSER PREVIEW</span></div>
          <div className="media-preview" style={{ aspectRatio: project.aspectRatio.replace(':', '/') }}>
            {renderedVideoUrl ? <video
              className="rendered-video"
              src={renderedVideoUrl}
              controls
              playsInline
              aria-label={`Rendered MP4 preview for ${project.title}`}
              data-testid="video-rendered-preview"
            /> : <>
              {heroImage && <><img src={heroImage} className="preview-image" alt="Your uploaded media preview"/><div className="preview-overlay"/></>}
              <div className="ratio-tag">{project.aspectRatio}</div>
              <div className="preview-center">
                <div className="play-mark"><Play size={18} fill="currentColor"/></div>
                <div className="preview-title">{previewing ? (previewScene?.caption || project.title) : project.title}</div>
                <div className="preview-sub">{previewing ? 'Storyboard preview · visuals are yours' : 'A scene-by-scene preview'}</div>
              </div>
            </>}
          </div>
          <div className="timeline">{scenes.map((scene) => <div key={scene.id} className="timeline-seg" title={`Scene ${scene.order}: ${scene.durationSeconds}s`}/>)}</div>
          <div className="timeline-caption">{scenes.length} scenes <span style={{ float: 'right' }}>{formatTime(project.durationSeconds)}</span></div>
          <div style={{ display: 'flex', gap: 8, marginTop: 15 }}>
            <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => setPreviewing(!previewing)} data-testid="button-preview">{previewing ? <X size={13}/> : <Play size={13}/>} {previewing ? 'Stop preview' : 'Preview'}</button>
            <button className="btn btn-primary" style={{ flex: 1 }} onClick={queueMp4Render} disabled={createRenderJob.isPending || scenes.length === 0} data-testid="button-export-video">{createRenderJob.isPending ? <><LoaderCircle size={13} className="spin"/> Queueing…</> : <><ArrowDownToLine size={13}/> Render MP4</>}</button>
          </div>
          {createRenderJob.isError && <div className="error-box" role="alert" data-testid="status-render-create-error">
            {notice || 'The render request failed. Your project and selected media are still here.'}
            <button className="upload-action" style={{ marginLeft: 7 }} onClick={queueMp4Render} data-testid="button-retry-render">Retry render</button>
          </div>}
          {renderJobId && <div className="render-status" aria-live="polite" data-testid="status-render-job">
            {renderQuery.isLoading && <><div className="render-status-head"><LoaderCircle size={13} className="spin"/> Checking render job</div><div className="field-hint">Job {renderJobId}</div></>}
            {renderQuery.isError && <><div className="render-status-head"><CircleAlert size={14} color="#a8513e"/> Status unavailable</div><p className="field-hint">The job may still be processing. Retry the status check; this will not queue another render.</p><button className="upload-action" onClick={() => renderQuery.refetch()} data-testid="button-retry-render-status">Retry status check</button></>}
            {renderQuery.data && <>
              <div className="render-status-head"><span className={`render-status-dot ${renderQuery.data.status === 'failed' ? 'failed' : renderQuery.data.status === 'complete' ? 'complete' : ''}`}/>{renderQuery.data.status === 'complete' ? 'MP4 ready' : renderQuery.data.status === 'failed' ? 'Render failed' : renderQuery.data.status === 'queued' ? 'Render queued' : 'Rendering on server'}</div>
              <div className="progress-track" role="progressbar" aria-valuenow={renderQuery.data.progress} aria-valuemin={0} aria-valuemax={100}><div className="progress-value" style={{ width: `${Math.min(100, Math.max(0, renderQuery.data.progress))}%` }}/></div>
              <div className="render-stage"><span>{renderQuery.data.stage || renderQuery.data.status}</span><span>{renderQuery.data.progress}%</span></div>
              {renderQuery.data.message && <p className="field-hint">{renderQuery.data.message}</p>}
              {renderQuery.data.error && <div className="error-box" role="alert">{renderQuery.data.error}<button className="upload-action" style={{ marginLeft: 7 }} onClick={queueMp4Render} data-testid="button-retry-failed-render">Try a new render</button></div>}
              {renderQuery.data.status === 'complete' && <>
                <a href={getDownloadRenderedVideoUrl(renderJobId)} className="btn btn-primary" style={{ width: '100%', marginTop: 10 }} download={`${(project.title || 'reelforge-video').replace(/[^a-z0-9-_]+/gi, '-').toLowerCase()}.mp4`} data-testid="link-download-mp4"><ArrowDownToLine size={13}/> Download MP4{renderQuery.data.fileSizeBytes ? ` · ${(renderQuery.data.fileSizeBytes / (1024 * 1024)).toFixed(1)} MB` : ''}</a>
                <button className="btn btn-secondary" style={{ width: '100%', marginTop: 8 }} onClick={queueMp4Render} disabled={createRenderJob.isPending} data-testid="button-regenerate-video"><Clapperboard size={13}/> Render again</button>
              </>}
            </>}
          </div>}
          {!renderJobId && <div className="note-box">A server-side FFmpeg render creates the MP4. Genuine queued/running progress and any errors come from the render service. Selected media is sent with your render request; no AI images or voice are created.</div>}
        </section>
        <section className="card editor-card" style={{ marginTop: 13 }}>
          <div className="editor-header"><h2>Your sound</h2><span>OPTIONAL</span></div>
          <div className="upload-list">
            <UploadControl label="Narration audio" detail="Upload your own voice recording (12 MB max)" accept="audio/mpeg,audio/mp4,audio/x-m4a,audio/aac,audio/wav,audio/x-wav,audio/ogg,.mp3,.wav,.aac,.m4a,.ogg" icon={AudioLines} fileName={mediaNames.narration || ''} onFile={(file) => attachFile('narration', file)} testId="narration"/>
            <div className="volume-setting"><label htmlFor="narration-volume">Narration volume <span>{Math.round(narrationVolume * 100)}%</span></label><input id="narration-volume" type="range" min="0" max="2" step="0.05" value={narrationVolume} onChange={(event) => setNarrationVolume(Number(event.target.value))} data-testid="input-narration-volume"/></div>
            <UploadControl label="Licensed music" detail="Use music you have permission to use (12 MB max)" accept="audio/mpeg,audio/mp4,audio/x-m4a,audio/aac,audio/wav,audio/x-wav,audio/ogg,.mp3,.wav,.aac,.m4a,.ogg" icon={Music2} fileName={mediaNames.music || ''} onFile={(file) => attachFile('music', file)} testId="music"/>
            <div className="volume-setting"><label htmlFor="music-volume">Music volume <span>{Math.round(musicVolume * 100)}%</span></label><input id="music-volume" type="range" min="0" max="0.5" step="0.01" value={musicVolume} onChange={(event) => setMusicVolume(Number(event.target.value))} data-testid="input-music-volume"/></div>
          </div>
          <div className="note-box">Narration and optional music are mixed into the MP4. Scene captions use approximate scene timing, not word-level alignment. No hosted voice generation is connected.</div>
        </section>
      </aside>
    </div>
  </div>;
}

function SettingsPage() {
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), retry: 1 } });
  const capabilities = useGetCapabilities({ query: { queryKey: getGetCapabilitiesQueryKey(), retry: 1 } });
  return <div className="page fade-in">
    <div className="eyebrow"><Settings2 size={13}/> Studio details</div>
    <h1 className="page-title">Know where your work lives.</h1>
    <p className="page-subtitle">ReelForge keeps the workflow understandable: local drafts, explicit limits, and no pretend AI generation.</p>
    <div className="settings-grid">
      <section className="card setting-card"><div className="setting-icon"><ShieldCheck size={17}/></div><h2>Saved on this device</h2><p>Project metadata is stored in this browser's local storage. It is not uploaded, backed up, or synced across devices. Clearing site data removes your projects. Media stays in this editing session until you explicitly request an MP4 render; then selected files are sent to the render service.</p></section>
      <section className="card setting-card"><div className="setting-icon"><WandSparkles size={17}/></div><h2>Template text, not AI</h2><p>The connected draft endpoint uses deterministic templates to create starter copy. No hosted model is connected. Script, narration, image, and video generation are not represented as AI output.</p></section>
      <section className="card setting-card"><div className="setting-icon"><Image size={17}/></div><h2>Your licensed media</h2><p>Upload imagery, narration, and music you own or have permission to use. Uploaded imagery is never described as generated. Files stay in the current editing session, not in cloud storage.</p></section>
      <section className="card setting-card"><div className="setting-icon"><Clapperboard size={17}/></div><h2>Server-side MP4 render</h2><p>When you choose Render MP4, scene metadata and your selected still images, narration, and licensed music are sent to the render service. FFmpeg creates the MP4 asynchronously. Live stage and progress are returned by that service. No AI imagery or synthetic narration is included.</p></section>
    </div>
    <div className="settings-callout"><CircleAlert size={17} style={{ flex: '0 0 auto', color: '#e8a384', marginTop: 1 }}/><p><strong>Service check</strong>{health.isLoading ? 'Checking the script service…' : health.isError ? 'The project API is currently unreachable. Existing local drafts are still available; template draft creation needs the API.' : `Draft service: ${health.data?.status || 'connected'}. ${capabilities.data?.notice || 'Hosted AI providers are not included.'}`}</p></div>
    <div className="section-head"><div><h2>Studio capability report</h2><p>Live information from the connected service, when available.</p></div></div>
    <div className="status-grid">
      {capabilities.isLoading ? <><div className="skeleton"/><div className="skeleton"/><div className="skeleton"/></> : capabilities.isError ? <div className="error-box" role="alert">Could not load the capability report. Check the API connection and <button className="upload-action" onClick={() => capabilities.refetch()} data-testid="button-retry-capabilities">retry</button>.</div> : capabilities.data ? [
        ['Script drafts', capabilities.data.scriptGeneration],
        ['Image generation', capabilities.data.imageGeneration],
        ['Narration', capabilities.data.narration],
        ['Rendering', capabilities.data.rendering],
        ['Storage', capabilities.data.storage],
        ['Service note', capabilities.data.notice],
      ].map(([label, value]) => <div className="status-card" key={label}><div className="status-top"><span>{label}</span><CircleAlert size={13} color="hsl(var(--muted-foreground))"/></div><div className="status-detail" style={{ marginTop: 9 }} data-testid={`text-capability-${label.toLowerCase().replace(' ', '-')}`}>{value}</div></div>) : null}
    </div>
  </div>;
}

function Router() {
  return <RoutedErrorBoundary><Shell><Switch>
    <Route path="/" component={Dashboard}/>
    <Route path="/create" component={CreatePage}/>
    <Route path="/project/:id" component={ProjectPage}/>
    <Route path="/settings" component={SettingsPage}/>
    <Route component={NotFound}/>
  </Switch></Shell></RoutedErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
        <Router/>
      </WouterRouter>
      <Toaster/>
    </TooltipProvider>
  </QueryClientProvider>;
}
export default App;